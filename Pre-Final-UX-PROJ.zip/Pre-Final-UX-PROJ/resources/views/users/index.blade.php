@extends('layouts.master')

@section('body')
    <section id="user_section" class="pt-5">
        <div class="page-title">
            <div class="container">
                <h1 class="text-light mt-4 py-3">User</h1>
            </div>
        </div>
        <div class="container">
            <table class="table table-bordered table-responsive">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">First Name</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Username</th>
                    <th scope="col">Role</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </section>
@endsection
