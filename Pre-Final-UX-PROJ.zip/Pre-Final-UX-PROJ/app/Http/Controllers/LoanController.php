<?php

namespace App\Http\Controllers;

use App\Models\Loan;
use App\Models\Log;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class LoanController extends Controller
{
    public function store(Request $request)
    {
        $this->validate($request, [
            'book_id' => 'required',
            'due' => 'date',
            'role' => 'required',
        ]);
        DB::beginTransaction();
        $log = Log::query()->create([
            'book_id' => $request->book_id,
            'role' => $request->role,
        ]);
        $loan = Loan::query()->create([
            'user_id' => Auth::id(),
            'book_id' => $request->book_id,
            'log_id' => $log->id,
            'due' => new Carbon($request->due),
        ]);
        DB::commit();
        if($loan) {
            return response()->json();
        }

        return response()->json([], 500);
    }

    public function index(Request $request)
    {
        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }

        $books = Loan::query()
            ->when($request->book_id, function ($query, $book_id) {
                $query->where('book_id', $book_id);
            })
            ->get()
            ->map(function ($loan) {
                return [
                    'user' => [
                        'full_name' => $loan->user->full_name
                    ],
                    'book' => [
                        'name' => $loan->book->name
                    ],
                    'log' => [
                        'role' => $loan->log->role,
                    ],
                    'due' => $loan->due
                ];
            });
        return response()->json($books);
    }
}
