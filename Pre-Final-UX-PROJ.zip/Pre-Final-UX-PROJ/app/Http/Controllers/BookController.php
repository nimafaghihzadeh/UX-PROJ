<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BookController extends Controller
{

    public function store(Request $request)
    {

        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }
        $this->validate($request, [
            'name' => 'required',
            'title' => 'required',
            'copies_available' => 'required|numeric',
            'published_year' => 'required|numeric',
            'author_id' => 'required|numeric',
            'type' => 'required',
        ]);

        $book = Book::query()->create($request->all());
        if($book) {
            return response()->json();
        }
        return response()->json([], 500);
    }

    public function index()
    {
        $books = Book::query()->get()->toArray();
        return response()->json($books);
    }

    public function update(Request $request, Book $book)
    {
        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }
        $this->validate($request, [
            'name' => 'required',
            'title' => 'required',
            'copies_available' => 'required|numeric',
            'published_year' => 'required|numeric',
            'author_id' => 'required|numeric',
            'type' => 'required',
        ]);

        if($book->update($request->all())) {
            return response()->json();
        }
        return response()->json([], 500);
    }

    public function delete(Book $book)
    {
        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }

        if($book->delete()) {
            return response()->json();
        }
        return response()->json([], 500);
    }

    public function show(Book $book)
    {
        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }
        return response()->json($book->toArray());
    }
}
