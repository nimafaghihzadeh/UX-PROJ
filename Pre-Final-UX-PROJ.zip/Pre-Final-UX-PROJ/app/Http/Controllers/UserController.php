<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class UserController extends Controller
{
    public function menu()
    {
        $auth = Auth::user();
        return response()->json([
            'id' => $auth ? $auth->id: null,
            'role' => $auth ? $auth->role: null,
        ]);
    }

    public function login(Request $request)
    {
        $this->validate($request, [
            'username' => 'required',
            'password' => 'required'
        ]);

        if($limit = Session::get('limit', 0) >= 1000) {
            return response()->json([], 403);
        }

        if(Auth::attempt(['username' => $request->username, 'password' => $request->password])) {
            $user = User::query()->where('username', $request->username)->first();
            $user->ip = $request->ip();
            $user->save();
            Session::put('limit', $limit+1);

            return response()->json(['id' => $user->id, 'role' => $user->role]);
        }
        return response()->json([], 404);
    }


    public function register(Request $request)
    {
        $this->validate($request, [
            'username' => 'required|unique:users,username',
            'password' => 'required|confirmed',
        ]);


        if($limit = Session::get('limit', 0) >= 1000) {
            return response()->json([], 403);
        }

        $user = User::query()->create([
            'firstname' => '',
            'lastname' => '',
            'username' => $request->username,
            'password' => Hash::make($request->password),
            'role' => 'member',
            'image' => '',
            'ip' => $request->ip()
        ]);
        if($user) {
            Session::put('limit', $limit+1);
            return response()->json(['id' => $user->id, 'role' => $user->role]);
        }
        return response()->json([], 500);
    }

    public function index()
    {
        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }

        $users = User::query()->get()->toArray();
        return response()->json($users);
    }

    public function update(Request $request, User $user)
    {
        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }

        $this->validate($request, [
            'firstname' => 'required',
            'lastname' => 'required',
            'username' => 'required|unique:users,username,' . $user->id,
        ]);

        $params = $request->all();
        if(isset($params['password'])) {
            $params['password'] = Hash::make($params['password']);
        }

        if($user->update($params)) {
            return response()->json();
        }
        return response()->json([], 500);
    }

    public function show(User $user)
    {
        $user->ip = request()->ip();
        $user->save();

        return response()->json($user->toArray());
    }
}
