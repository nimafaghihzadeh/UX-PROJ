<?php

namespace App\Http\Controllers;

use App\Models\Author;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthorController extends Controller
{
    public function store(Request $request)
    {
        $this->validate($request, [
            'firstname' => 'required',
            'lastname' => 'required',
            'birthdate' => 'required|datetime',
            'image' => 'required',
            'author_id' => 'required|exists:authors,id',
        ]);

        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }

        $author = Author::query()->create([
            'firstname' => $request->firstname,
            'lastname' => $request->lastname,
            'birthdate' => new Carbon($request->birthdate),
            'image' => ''
        ]);
        if($author) {
            return response()->json();
        }
        return response()->json([], 500);
    }

    public function index()
    {
        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }

        $users = Author::query()->get()->toArray();
        return response()->json($users);
    }

    public function update(Request $request, Author $author)
    {
        $this->validate($request, [
            'firstname' => 'required',
            'lastname' => 'required',
            'birthdate' => 'required|datetime',
            'image' => 'required',
        ]);

        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }

        if($author->update($request->all())) {
            return response()->json();
        }
        return response()->json([], 500);
    }

    public function delete(Author $author)
    {
        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }

        if($author->delete()) {
            return response()->json();
        }
        return response()->json([], 500);
    }
}
