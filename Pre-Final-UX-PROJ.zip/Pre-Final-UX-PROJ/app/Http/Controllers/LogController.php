<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LogController extends Controller
{
    public function store(Request $request)
    {
        $this->validate($request, [
            'book_id' => 'required',
            'role' => 'required',
        ]);
        $log = Log::query()->create([
            'book_id' => $request->book_id,
            'role' => $request->role,
        ]);
        if($log) {
            return response()->json($log->toArray());
        }
        return response()->json([], 500);
    }

    public function index(Request $request)
    {
        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }

        $books = Log::query()
            ->when($request->book_id, function ($query, $book_id) {
                $query->where('book_id', $book_id);
            })
            ->get()
            ->map(function ($log) {
                return [
                    'id' => $log->id,
                    'name' => $log->book->name,
                    'role' => $log->role,
                ];
            });
        return response()->json($books);
    }
}
