<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommentController extends Controller
{

    public function store(Request $request)
    {
        $this->validate($request, [
            'book_id' => 'required|exists:books,id',
            'text' => 'required',
        ]);

        $params = $request->all();
        $params['user_id'] = Auth::id();
        $comment = Comment::query()->create($params);
        if($comment) {
            return response()->json();
        }
        return response()->json([], 500);
    }

    public function index()
    {
        $auth = Auth::user();
        if(is_null($auth) || $auth->role != 'admin') {
            return response()->json([], 403);
        }

        $comments = Comment::query()
            ->get()
            ->map(function ($comment) {
                return [
                    'user' => [
                        'full_name' => $comment->user->full_name
                    ],
                    'text' => $comment->text
                ];
            });
        return response()->json($comments);
    }

    public function fetch($id)
    {
        $comments = Comment::query()
            ->where('book_id', $id)
            ->get()
            ->map(function ($comment) {
                return [
                    'user' => [
                        'full_name' => $comment->user->full_name
                    ],
                    'text' => $comment->text
                ];
            });
        return response()->json($comments);
    }
}
