

let url = $('meta[name=url]').attr('content');
let id = $.cookie('id');
let role = $.cookie('role');

if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register(`${url}/js/serviceworker.js`).then(function(reg) {

        if(reg.installing) {
            console.log('Service worker installing');
        } else if(reg.waiting) {
            console.log('Service worker installed');
        } else if(reg.active) {
            console.log('Service worker active');
        }

    }).catch(function(error) {
        // registration failed
        console.log('Registration failed with ' + error);
    });
}

$(document ).ready(function() {
    // logout after 5 minute
    setTimeout(function (){

        $.removeCookie('id')
        $.removeCookie('role')
        window.location = `${url}`

    }, 1000*60*5);

    $.validator.addMethod("isUsername", function(value, element) {
        return /^[A-Za-z0-9\d=!\-@._*]*$/.test(value)
    }, 'please enter username');

    $.validator.addMethod("isEmail", function(value, element) {
        return this.optional(element) || /(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/i.test(value);
    }, 'please enter email');

    $.validator.addMethod("isPass", function(value) {
        return /^[A-Za-z0-9\d=!\-@._*]*$/.test(value) // consists of only these
            && /[a-z]/.test(value) // has a lowercase letter
            && /\d/.test(value) // has a digit
    }, 'please enter strong password');

    function errorPlacement ( error, element ) {
        error.addClass( "invalid-feedback" );

        if ( element.prop( "type" ) === "checkbox" ) {
            element.closest(".checkbox").toggleClass("invalid");
        } else {
            element.parent().append(error);
        }
    }

    function error( message, element ) {
        if ( element.prop( "type" ) === "checkbox" ) {
            element.closest(".checkbox").toggleClass("invalid");
        } else {
            element.addClass('is-invalid')
            element.parent().append(`<div class="invalid-feedback">${message}</div>`);
        }
    }

    function highlight ( element, errorClass, validClass ) {
        $(element).addClass( "is-invalid" );
    }

    function unHighlight (element, errorClass, validClass) {
        $(element).removeClass( "is-invalid" );
    }
    const errorElement = "div";

    if(id) {
        $('#profile').removeClass('d-none')
        $('#books').removeClass('d-none')
        $('#logout').removeClass('d-none')
        if(role === 'admin') {
            $('#create-book').removeClass('d-none')
            $('#logs').removeClass('d-none')
            $('#loans').removeClass('d-none')
            $('#comments').removeClass('d-none')
        }
    }
    else {
        $('.sign_in').removeClass('d-none')
        $('.sign_up').removeClass('d-none')
    }


    mode($.cookie('mode') ? $.cookie('mode') : 'light');
    $('[name=mode]').change(function () {
        $.cookie('mode', $(this).val());
        mode($(this).val());
    });

    $('#logout').click( function () {
        $.removeCookie('id');
        $.removeCookie('role');
        window.location = `${url}`
    })

    $(".login-form").validate( {
        rules: {
            username: {
                required: true,
                isUsername: true
            },
            password: {
                required: true,
            },
        },
        messages: {
            username: {
                required: "username is require",
            },
            password: {
                required: "password is require",
            },
        },
        errorElement,
        errorPlacement,
        highlight,
        unHighlight,
        submitHandler: function (form) {
            $('.loading').removeClass('d-none');
            $.post({
                url: `${url}/ajax/login`,
                data: {
                    'username' : $('#sign_in_username').val(),
                    'password' : $('#sign_in_password').val(),
                },
                success: function (response) {
                    $.cookie('id', response.id);
                    $.cookie('role', response.role);
                    window.location = `${url}/books`
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert('username or password incorrect')
                }
            });
            $('.loading').addClass('d-none');
            return false;
        }
    } );

    $(".register-form").validate( {
        rules: {
            username: {
                required: true,
                isUsername: true
            },
            password: {
                required: true,
                isPass: true,
                minlength: 5
            },
            repassword: {
                required: true,
                isPass: true,
                minlength: 5,
                equalTo: "#sign_up_repassword"
            },
        },
        messages: {
            username: {
                required: "username is require",
            },
            password: {
                required: "username is require",
                equalTo: "confirm password equal to password",
            },
        },
        errorElement,
        errorPlacement,
        highlight,
        unHighlight,
        submitHandler: function (form) {
            $('.loading').removeClass('d-none');
            $.post({
                url: `${url}/ajax/register`,
                data: {
                    'username' : $('#sign_up_username').val(),
                    'password' : $('#sign_up_password').val(),
                    'password_confirmation' : $('#sign_up_repassword').val(),
                },
                success: function (response) {
                    $.cookie('id', response.id);
                    $.cookie('role', response.role);
                    window.location = `${url}/books`
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert('user not found')
                }
            });
            $('.loading').addClass('d-none');
            return false;
        }
    } );

    if($('#book_section').length) {
        if(id && role === 'admin') {
            let response = JSON.parse(localStorage.getItem('authors'));
            if(! response) {
                $('.loading').removeClass('d-none');
                $.get({
                    url: `${url}/ajax/authors`,
                    success: function (response) {
                        localStorage.setItem('authors', JSON.stringify(response));
                    },
                    complete: function (){
                    }
                });
                $('.loading').addClass('d-none');
            }
            response = JSON.parse(localStorage.getItem('authors'));
            let html = '';
            for (let i in response) {
                let item = response[i];
                html += ` <option value="${item.id}">${item.firstname} ${item.lastname}</option> `
            }
            $('#author_id').html(html);
        }
        let response = JSON.parse(localStorage.getItem('books'));
        if(!response) {
            $('.loading').removeClass('d-none');
            $.get({
                url: `${url}/ajax/books`,
                success: function (response) {
                    localStorage.setItem('books', JSON.stringify(response));
                }
            });
            $('.loading').addClass('d-none');
        }

        response = JSON.parse(localStorage.getItem('books'));
        if(response) {
            let ebooks = response.filter(function (book) {
                return book.type === 'ebook';
            });
            let podcasts = response.filter(function (book) {
                return book.type === 'podcast';
            });
            let html = '<div class="row">';

            for (let i in ebooks) {
                let item = ebooks[i];
                html += `
        <div class="col-md-3 mt-2">
          <div class="card">
              <img src="img/4.jpg" class="card-img-top" alt="book image">
              <div class="card-body">
                <h5 class="card-title">${item.name}</h5>
                <p class="card-text">${item.title}</p>
                    <button class="btn btn-sm mr-1 btn-primary" onclick="storeLog(${item.id})">Read More</button>`
                if (role === 'member' || role === 'admin') {
                    html += `<button class="btn btn-success btn-sm mr-1" onclick="showLoanModal(${item.id})">loan</button>`
                    html += `<button class="btn btn-light btn-sm mr-1" onclick="showCommentModal(${item.id})">comment</button>`
                }
                if (role === 'admin') {
                    html += `
                            <div class="d-flex mt-3">
                            <button class="btn  mr-1 btn-sm btn-warning" onclick="editBook(${item.id})">edit</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteBook(${item.id})">remove</button>
                            </div>`
                }
                html += `</div>
              <div class="card-footer">Published at ${item.published_year}</div>
            </div>
          </div> `;
            }
            html += '</div>'
            $('#ebook').html(html);

            html = '<div class="row">';
            for (let i in podcasts) {
                let item = podcasts[i];
                html += `
        <div class="col-md-3 mt-2">
          <div class="card">
              <img src="img/4.jpg" class="card-img-top" alt="book image">
              <div class="card-body">
                <h5 class="card-title">${item.name}</h5>
                <p class="card-text">${item.title}</p>

                    <button class="btn btn-sm btn-primary mr-1" onclick="storeLog(${item.id})">Read More</button>`
                if (role === 'member' || role === 'admin') {
                    html += `<button class="btn btn-success btn-sm mr-1">loan</button>`
                }
                if (role === 'admin') {
                    html += `<div class="d-flex mt-3">
                            <button class="btn  mr-1 btn-sm btn-warning" onclick="editBook(${item.id})">edit</button>
                                <button class="btn btn-danger btn-sm" onclick="deleteBook(${item.id})">remove</button>
                            </div>`
                }
                html += `</div>
              <div class="card-footer">Published at ${item.published_year}</div>
            </div>
          </div>
        `;
            }
            html += '</div>'
            $('#podcast').html(html);
        }
    }

    if($('#author_section').length) {
        let response = JSON.parse(localStorage.getItem('authors'));
        if(! response) {
            $('.loading').removeClass('d-none');
            $.get({
                url: `${url}/ajax/authors`,
                success: function (response) {
                    localStorage.setItem('authors', JSON.stringify(response));
                }
            });
            $('.loading').addClass('d-none');
        }

        response = JSON.parse(localStorage.getItem('authors'));
        for (let i in response) {
            let item = response[i];
            html += `

            <tr>
                <th scope="row">${item.id}</th>
                <td>${item.firstname}</td>
                <td>${item.lastname}</td>
                <td>${item.birthdate}</td>
                <td>`
            if (role === 'admin') {
                html += `
                            <div class="d-flex mt-3">
                            <a href="${url + '/authors/' + item.id + '/edit'}" class="btn  mr-1 btn-sm btn-warning">edit</a>
                            <button class="btn btn-danger btn-sm" onclick="deleteAuthor(${item.id})">remove</button>
                            </div>`
            }
            html += `</td>
            </tr>`
        }
        $('#author_section tbody').html(html);
    }

    if($('#loan_section').length) {
        let response = JSON.parse(localStorage.getItem('loans'));
        if(! response) {
            $('.loading').removeClass('d-none');
            $.get({
                url: `${url}/ajax/loans`,

                success: function (response) {
                    localStorage.setItem('loans', JSON.stringify(response));
                },
                complete: function () {
                }
            });
            $('.loading').addClass('d-none');
        }
        response = JSON.parse(localStorage.getItem('loans'));
        let html = '';
        for (let i in response) {
            let item = response[i];
            html += `
            <tr>
                <th scope="row">${item.id}</th>
                <td>${item.book.name}</td>
                <td>${item.user.full_name}</td>
                <td>${item.log.role}</td>
                <td>${item.due}</td>
            </tr>`
        }
        $('#loan_section tbody').html(html);
    }

    if($('#comment_section').length) {
        let response = JSON.parse(localStorage.getItem('comments'));
        if(! response) {
            $('.loading').removeClass('d-none');
            $.get({
                url: `${url}/ajax/comments`,
                success: function (response) {
                    localStorage.setItem('comments', JSON.stringify(response));
                }
            });
            $('.loading').addClass('d-none');
        }
        response = JSON.parse(localStorage.getItem('comments'));
        let html = '';
        for (let i in response) {
            let item = response[i];
            html += `
            <tr>
                <td>${item.user.full_name}</td>
                <td>${item.text}</td>
            </tr>`
        }
        $('#comment_section tbody').html(html);
    }

    if($('#log_section').length) {
        let response = JSON.parse(localStorage.getItem('logs'));
        if(! response) {
            $('.loading').removeClass('d-none');
            $.get({
                url: `${url}/ajax/logs`,

                success: function (response) {
                    localStorage.setItem('logs', JSON.stringify(response));
                }
            });
            $('.loading').addClass('d-none');
        }
        response = JSON.parse(localStorage.getItem('logs'));
        let html = '';
        for (let i in response) {
            let item = response[i];
            html += `
            <tr>
                <th scope="row">${item.id}</th>
                <td>${item.name}</td>
                <td>${item.role}</td>
            </tr>`
        }
        $('#log_section tbody').html(html);
    }

    if($('#user_section').length) {
        let response = JSON.parse(localStorage.getItem('comments'));
        if(! response) {
            $('.loading').removeClass('d-none');
            $.get({
                url: `${url}/ajax/users`,
                success: function (response) {
                    localStorage.setItem('users', JSON.stringify(response));
                }
            });
            $('.loading').addClass('d-none');
        }
        response = JSON.parse(localStorage.getItem('users'));
        let html = '';
        for (let i in response) {
            let item = response[i];
            html += `
            <tr>
                <th scope="row">${item.id}</th>
                <td>${item.firstname}</td>
                <td>${item.lastname}</td>
                <td>${item.username}</td>
                <td>${item.role}</td>
            </tr>`
        }
        $('#user_section tbody').html(html);
    }

    if($('#profile_section').length) {
        $('.loading').removeClass('d-none');
        $.get({
            url: `${url}/ajax/users/${id}`,
            success: function (response) {
                $('#profile_section #id').val(id);
                $('#profile_section #firstname').val(response.firstname);
                $('#profile_section #lastname').val(response.lastname);
                $('#profile_section #username').val(response.username);
                $('#profile_section #password').val(response.password);
                $('#profile_section #ip span').text(response.ip);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('user not found')
            }
        });
        $('.loading').addClass('d-none');
    }

    $('#btn-store-comment').click(function() {
        $('.loading').removeClass('d-none');
        $.post({
            url: `${url}/ajax/comments`,
            data: {
                'book_id' : $('#book_id_comment').val(),
                'text' : $('#text').val(),
            },
            success: function (response) {
                alert('store comment success')
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('store comment fail')
            }
        });
        $('#commentModal').modal('hide')
        $('.loading').addClass('d-none');

    });

    $('#btn-store-edit-book').click(function() {
        let id = $('#book_id').val();
        $('.loading').removeClass('d-none');
        if(id) {
            $.post({
                url: `${url}/ajax/books/${id}/update`,
                data: {

                    name: $('#editModal #name').val(),
                    title: $('#editModal #title').val(),
                    copies_available: $('#editModal #copies_available').val(),
                    published_year: $('#editModal #published_year').val(),
                    author_id: $('#editModal #author_id').val(),
                    type: $('#editModal #type').val(),
                },
                success: function (response) {
                    alert('update comment success')
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert('store comment fail')
                }
            });
        }

        else {
            $.post({
                url: `${url}/ajax/books/`,
                data: {
                    name: $('#editModal #name').val(),
                    title: $('#editModal #title').val(),
                    copies_available: $('#editModal #copies_available').val(),
                    published_year: $('#editModal #published_year').val(),
                    author_id: $('#editModal #author_id').val(),
                    type: $('#editModal #type').val(),
                },
                success: function (response) {
                    alert('store comment success')
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert('store comment fail')
                }
            });

        }
        $('#editModal').modal('hide')

        $('.loading').addClass('d-none');
    });

    $('#btn-update-profile').click(function() {
        let data = {
            'firstname' : $('#profile_section #firstname').val(),
            'lastname' : $('#profile_section #lastname').val(),
            'username' : $('#profile_section #username').val(),
        }
        if($('#profile_section #password').val()) {
            data['password'] = $('#profile_section #password').val();
        }
        $('.loading').removeClass('d-none');
        $.post({
            url: `${url}/ajax/update/${id}`,
            data: data,
            success: function (response) {
                alert('store log success')
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('store log fail')
            }
        });
        $('.loading').addClass('d-none');
    });
});

function storeLog(id) {
    $('.loading').removeClass('d-none');
    $.post({
        url: `${url}/ajax/logs`,
        data: {
            'book_id' : id,
            'role' : role ? role : 'guest',
        },
        success: function (response) {
            alert('store log success')
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert('store log fail')
        }
    });
    $('.loading').addClass('d-none');
}

function deleteBook(id) {
    $('.loading').removeClass('d-none');
    $.post({
        url: `${url}/ajax/books/${id}/delete`,
        success: function (response) {
            alert('delete book success')
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert('can not delete book')
        }
    });
    $('.loading').addClass('d-none');
}

function editBook(id) {
    $('#editModal').modal('show')
    $('#book_id').val(id)
    $('.loading').removeClass('d-none');
    $.get({
        url: `${url}/ajax/books/${id}`,
        success: function (response) {
            $('#editModal #name').val(response.name);
            $('#editModal #title').val(response.title);
            $('#editModal #copies_available').val(response.copies_available);
            $('#editModal #published_year').val(response.published_year);
            $('#editModal #author_id').val(response.author_id);
            $('#editModal #type').val(response.type);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert('can not get book')
        }
    });
    $('.loading').addClass('d-none');
}

function createBook(id) {
    $('#editModal').modal('show')
    $('#book_id').val('')
}

function showLoanModal(id) {
    $('#loadModal').modal('show')
    $('#book_id_loan').val(id)
}

function showCommentModal(id) {
    $('#commentModal').modal('show')
    $('#book_id_comment').val(id);
    $('.loading').removeClass('d-none');
    $.get({
        url: `${url}/ajax/comments/${id}`,
        success: function (response) {
            let html = '';
            for (let i in response) {
                let item = response[i];
                html += `
            <div class="p-2">
                <span class="d-block">${item.user.full_name}</span>
                <small>${item.text}</small>

            </div><hr>`
            }
            $('#commentModal #comments').html(html);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert('comments not found')
        }
    });
    $('.loading').addClass('d-none');

}

function mode(mode) {
    if(mode === 'light') {
        $('body').addClass('light');
        $('body').removeClass('dark');
    }
    else {
        $('body').addClass('dark');
        $('body').removeClass('light');
    }
}

$('.btn-store-loan').click(function () {
    $('#loadModal').modal('hide')
    $('.loading').removeClass('d-none');
    $.post({
        url: `${url}/ajax/loans`,
        data: {
            'due' : $('#due').val(),
            'role': role,
            'book_id' : $('#book_id_loan').val(),
        },
        success: function (response) {
            alert('store loan success')
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert('store loan fail')
        }
    });
    $('.loading').addClass('d-none');
});
