<?php $__env->startSection('body'); ?>
    <section id="log_section" class="pt-5">
        <div class="page-title">
            <div class="container">
                <h1 class="text-light mt-4 py-3">Logs</h1>
            </div>
        </div>
        <div class="container">

            <table class="table table-bordered table-responsive">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Book Name</th>
                    <th scope="col">Role</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\non-master-final\resources\views/logs/index.blade.php ENDPATH**/ ?>