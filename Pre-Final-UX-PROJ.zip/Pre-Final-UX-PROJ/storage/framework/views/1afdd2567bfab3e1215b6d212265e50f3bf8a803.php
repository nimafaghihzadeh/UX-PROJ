<?php $__env->startSection('body'); ?>

    <!-- HERO SECTION -->
    <section id="hero-section">
        <div class="container pt-5">
            <div class="row justify-content-center mt-5">
                <div class="col-9 py-5 text-center">
                    <h1 class="display-4 text-uppercase text-light mt-5 p-4">Start reading books online</h1>
                    <div>
                        <!-- <a href="user-dashboard.html"><button class="btn btn-light w-25 btn-lg hero-btn" id="get-started-btn">Get Started!</button></a> -->
                        <a class="btn btn-light w-25 btn-lg hero-btn" href="<?php echo e(url('/books')); ?>">Get Started!</a>
                        <a href="#signIn-section"><button class="btn btn-outline-light w-25 btn-lg hero-btn">Sign In</button></a>
                    </div>
                    <div class="signUp-span mt-3">
                        <span class="text-light p-2">Still don't have an account? <a href="#signUp-section">Sign Up</a></span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SIGN IN SECTION -->
    <section id="signIn-section" class="pb-5">
        <div class="container">
            <h2 class="text-uppercase pt-4 text-center">Sign IN</h2>
            <div class="row">
                <div class="col-md-7 mt-4">
                    <p class="lead">If you already have an account try loging in and enjoy our online bookshelf.</p>
                    <div class="login-form mt-5">
                        <div class="mb-3 input-group">
                            <span class="input-group-text"><i class="fa fa-user"></i></span>
                            <input type="text" class="form-control" id="sign_in_username" placeholder="username">
                        </div>
                        <div class="mb-3 input-group">
                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-lock"></i></span>
                            <input type="password" class="form-control" id="sign_in_password" placeholder="password">
                        </div>
                        <!-- <a href="user-dashboard.html"><div class="text-center"><button class="btn btn-primary w-50" id="sign-in-form-btn">Sign In</button></div></a> -->
                        <div class="text-center"><button class="btn btn-primary w-50" id="sign_in_btn">Sign In</button></div>
                    </div>
                </div>
                <div class="col-md-5 mt-4">
                    <img src="<?php echo e(asset('img/signIn.svg')); ?>" alt="signIN image" class="img-fluid">
                </div>
            </div>
        </div>
    </section>

    <!-- SIGN UP SECTION -->
    <section id="signUp-section" class="pt-5">
        <div class="container">
            <h2 class="text-uppercase pt-4 text-center">Sign Up</h2>
            <div class="row">
                <div class="col-md-7 mt-4">
                    <p class="lead">If you don't have an account please fill out this form to be one of us and then you can use our online bookshelf.</p>
                    <div class="login-form mt-5">
                        <div class="mb-3 input-group">
                            <span class="input-group-text"><i class="fa fa-user"></i></span>
                            <input type="text" class="form-control" id="sign_up_username" placeholder="username">
                        </div>
                        <div class="mb-3 input-group">
                            <span class="input-group-text"><i class="fa fa-lock"></i></span>
                            <input type="password" class="form-control" id="sign_up_password" placeholder="password">
                        </div>
                        <div class="mb-3 input-group">
                            <span class="input-group-text"><i class="fa fa-lock"></i></span>
                            <input type="password" class="form-control" id="sign_up_repassword" placeholder="repeat password">
                        </div>
                        <div class="text-center"><button class="btn btn-primary w-50" id="sign_up_btn">Sign Up</button></div>
                    </div>
                </div>
                <div class="col-md-5 mt-4">
                    <img src="<?php echo e(asset('img/signUp.svg')); ?>" alt="signUp image" class="img-fluid">
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\non-master-final\resources\views/index.blade.php ENDPATH**/ ?>