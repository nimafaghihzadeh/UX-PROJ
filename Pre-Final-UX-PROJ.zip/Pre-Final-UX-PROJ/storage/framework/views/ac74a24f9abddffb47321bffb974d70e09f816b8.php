<nav class="navbar navbar-expand-md navbar-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('img/navbar-brand.png')); ?>" id="navbar-brand" width="50" height="50" alt="navbar-brand"></a>
        <!-- <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar">
            <span class="navbar-toggler-icon"></span>
        </button> -->
        <div class="collapse navbar-collapse" id="navbar">
            <ul class="navbar-nav me-auto mb-3 mb-md-0">
                <li class="nav-item">
                    <a class="nav-link active" id="main-home" href="<?php echo e(url('/')); ?>">Home</a>
                </li>

                <li class="nav-item d-none" id="sign_in">
                    <a class="nav-link home-link" href="<?php echo e(url('/')); ?>#signIn-section">Sign In</a>
                </li>
                <li class="nav-item d-none" id="sign_up">
                    <a class="nav-link home-link" href="<?php echo e(url('/')); ?>#signUp-section">Sign Up</a>
                </li>
                <li class="nav-item d-none" id="profile">
                    <a class="nav-link home-link" href="<?php echo e(url('/profile')); ?>">Profile</a>
                </li>
                <li class="nav-item d-none" id="books">
                    <a class="nav-link home-link" href="<?php echo e(url('/books')); ?>">Books</a>
                </li>
                <li class="nav-item d-none" id="logs">
                    <a class="nav-link home-link" href="<?php echo e(url('/logs')); ?>">Logs</a>
                </li>
                <li class="nav-item d-none" id="loans">
                    <a class="nav-link home-link" href="<?php echo e(url('/loans')); ?>">Loans</a>
                </li>
                <li class="nav-item d-none" id="comments">
                    <a class="nav-link home-link" href="<?php echo e(url('/comments')); ?>">Comments</a>
                </li>
                <li class="nav-item d-none" id="logout">
                    <a class="nav-link home-link" href="#">Logout</a>
                </li>
            </ul>

            <div class="btn-group btn-group-toggle ml-auto" data-toggle="buttons">
                <label class="btn btn-light active">
                    <input type="radio" name="mode" value="light" autocomplete="off" checked> light
                </label>
                <label class="btn btn-secondary">
                    <input type="radio" name="mode" value="dark" autocomplete="off"> dark
                </label>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\non-master-final\resources\views/layouts/header.blade.php ENDPATH**/ ?>