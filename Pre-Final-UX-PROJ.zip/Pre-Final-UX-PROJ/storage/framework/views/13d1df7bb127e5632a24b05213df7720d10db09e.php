<?php $__env->startSection('body'); ?>
    <section id="comment_section" class="pt-5">
        <div class="page-title">
            <div class="container">
                <h1 class="text-light mt-4 py-3">Comments</h1>
            </div>
        </div>
        <div class="container">
            <table class="table table-bordered table-responsive">
                <thead>
                <tr>
                    <th scope="col">User Name</th>
                    <th scope="col">Text</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\non-master-final\resources\views/comments/index.blade.php ENDPATH**/ ?>