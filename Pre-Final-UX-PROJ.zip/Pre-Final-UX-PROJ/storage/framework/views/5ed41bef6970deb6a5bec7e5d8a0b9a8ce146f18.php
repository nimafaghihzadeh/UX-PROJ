<?php $__env->startSection('body'); ?>
    <section id="loan_section" class="pt-5">
        <div class="page-title">
            <div class="container">
                <h1 class="text-light mt-4 py-3">Loans</h1>
            </div>
        </div>
        <div class="container">
            <table class="table table-bordered table-responsive">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Book Name</th>
                    <th scope="col">User Name</th>
                    <th scope="col">Role</th>
                    <th scope="col">Due Date</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Semester-3-UX-&-PROJ-Assignments\Pre-Final-UX-PROJ\resources\views/loans/index.blade.php ENDPATH**/ ?>