<?php $__env->startSection('body'); ?>
    <section id="book_section" class="pt-5">
        <div class="page-title">
            <div class="container">
                <div id="create-book" class="float-right mt-4 d-none">
                    <button class="btn btn-sm btn-primary" onclick="createBook()">create</button>
                </div>
                <h1 class="text-light mt-4 py-3">Books</h1>
            </div>
        </div>
        <div class="container mt-5">
            <ul class="nav nav-tabs" id="tabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="ebook-tab" data-toggle="tab" href="#ebook" role="tab" aria-controls="ebook" aria-selected="true">EBook</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="podcast-tab" data-toggle="tab" href="#podcast" role="tab" aria-controls="podcast" aria-selected="false">Podcast</a>
                </li>
            </ul>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="ebook" role="tabpanel" aria-labelledby="ebook-tab">
                </div>
                <div class="tab-pane fade" id="podcast" role="tabpanel" aria-labelledby="podcast-tab">
                </div>
            </div>
        </div>
    </section>
    <div class="modal fade" id="loadModal" tabindex="-1" role="dialog" aria-labelledby="loadModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="loadModalLabel">set due back</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="hidden" id="book_id_loan" value="">
                        <lable>due back date</lable>
                        <input type="date" id="due" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary btn-store-loan">Save</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="commentModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="loadModalLabel">write comment</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="hidden" id="book_id_comment" value="">
                        <lable>Text</lable>
                        <textarea id="text" class="form-control"></textarea>
                    </div>
                    <button type="button" class="btn btn-primary" id="btn-store-comment">Save</button>
                </div>
                <div id="comments">
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="commentModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="loadModalLabel">book</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="book_id" value="">
                    <div class="form-group">
                        <lable>name</lable>
                        <input id="name" class="form-control">
                    </div>
                    <div class="form-group">
                        <lable>title</lable>
                        <textarea id="title" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <lable>copies available</lable>
                        <input type="number" id="copies_available" class="form-control"></input>
                    </div>
                    <div class="form-group">
                        <lable>published year</lable>
                        <input type="number" id="published_year" class="form-control"></input>
                    </div>
                    <div class="form-group">
                        <lable>author</lable>
                        <select id="author_id" class="form-control"></select>
                    </div>
                    <div class="form-group">
                        <lable>type</lable>
                        <select id="type" class="form-control">
                            <option value="ebook">ebook</option>
                            <option value="podcast">podcast</option>
                        </select>
                    </div>
                    <button type="button" class="btn btn-primary" id="btn-store-edit-book">Save</button>
                </div>
                <div id="comments">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Semester-3-UX-&-PROJ-Assignments\Final-UX-PROJ\resources\views/books/index.blade.php ENDPATH**/ ?>