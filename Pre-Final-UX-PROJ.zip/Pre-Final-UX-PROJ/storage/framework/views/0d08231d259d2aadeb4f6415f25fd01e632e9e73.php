<?php $__env->startSection('body'); ?>
    <section id="profile_section" class="pt-5">
        <div class="page-title">
            <div class="container">
                <h1 class="text-light mt-4 py-3">Profile</h1>
            </div>
        </div>
        <div class="container">
            <div class="form-group">
                <label for="">firstname</label>
                <input name="firstname" id="firstname" class="form-control">
            </div>
            <div class="form-group">
                <label for="">lastname</label>
                <input name="lastname" id="lastname" class="form-control">
            </div>
            <div class="form-group">
                <label for="">username</label>
                <input name="username" id="username" class="form-control">
            </div>
            <div class="form-group">
                <label for="">password</label>
                <input type="password" name="password" id="password" class="form-control">
            </div>
            <div>
                <small id="ip">your ip : <span></span></small>
            </div>
            <button class="btn btn-sm mt-1 btn-primary" id="btn-update-profile">save</button>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nasser/Documents/www/Submission_Folder_For_UX2/non-master-final/resources/views/users/edit.blade.php ENDPATH**/ ?>