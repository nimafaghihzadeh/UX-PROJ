<?php

use Illuminate\Support\Facades\Route;

 


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::view('/', 'index');
Route::view('/books', 'books.index');
Route::view('/logs', 'logs.index');
Route::view('/loans', 'loans.index');
Route::view('/comments', 'comments.index');
Route::view('/profile', 'users.edit');

//rate limit api


 Route::group(['middleware' => ['throttle:1000,1440', 'throttle:60,1']], function () {
//    Route::group(['middleware' => 'throttle:1000,1440'], function () {
    Route::post('/ajax/login', 'UserController@login');
    Route::get('/ajax/menu', 'UserController@menu');
    Route::post('/ajax/register', 'UserController@register');
    Route::get('/ajax/index', 'UserController@index');
    Route::post('/ajax/update/{user}', 'UserController@update');
    Route::get('/ajax/users/{user}', 'UserController@show');

    Route::get('/ajax/books', 'BookController@index');
    Route::post('/ajax/books', 'BookController@store');
    Route::post('/ajax/books/{book}/delete', 'BookController@delete');
    Route::post('/ajax/books/{book}/update', 'BookController@update');
    Route::get('/ajax/books/{book}', 'BookController@show');

    Route::get('/ajax/comments', 'CommentController@index');
    Route::get('/ajax/comments/{id}', 'CommentController@fetch');
    Route::post('/ajax/comments', 'CommentController@store');

    Route::get('/ajax/logs', 'LogController@index');
    Route::post('/ajax/logs', 'LogController@store');

    Route::get('/ajax/loans', 'LoanController@index');
    Route::post('/ajax/loans', 'LoanController@store');

    Route::get('/ajax/authors', 'AuthorController@index');

});
